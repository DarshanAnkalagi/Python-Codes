n1=int(input("enter the first number: "))
n2=int(input("enter the second number: "))
add=n1+n2
sub=n1-n2
mul=n1*n2
div=n1/n2
print("addition: ",add)
print("substraction: ",sub)
print("multiplication: ",mul)
print("division: ",div)
