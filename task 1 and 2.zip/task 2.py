n1=input("enter first name: ")
n2=input("enter last name: ")
result=n1+" "+n2
print(f"Hello, {result}! welcome to the python program.")
